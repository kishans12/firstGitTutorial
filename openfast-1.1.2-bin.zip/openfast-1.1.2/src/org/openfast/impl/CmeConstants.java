package org.openfast.impl;

public class CmeConstants {
	final static int PREAMBLE_LEN = 5;
	final static long PREAMBLE_SEQ_NUM_MAX = 4294967295L;
	final static short PREAMBLE_SUB_ID_MAX = 127;
}
