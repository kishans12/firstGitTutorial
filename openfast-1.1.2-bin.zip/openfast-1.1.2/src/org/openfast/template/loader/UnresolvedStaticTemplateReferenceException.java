package org.openfast.template.loader;

public class UnresolvedStaticTemplateReferenceException extends RuntimeException {
    private static final long serialVersionUID = 1L;
    
}
