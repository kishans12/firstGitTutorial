USE [enginedb]
GO
CREATE PROCEDURE verifyDBVerAndUpdateScript	
AS
BEGIN		
	DECLARE @expectedVersion varchar(50);	
	DECLARE @currentVersion varchar(50);	
	SET @expectedVersion = '2.2.1.2';
	SET @currentVersion = (SELECT vv.VERSION FROM dbo.engine_version vv);	    
	IF @currentVersion = @expectedVersion				
		BEGIN
			DECLARE @newVersion varchar(50);
			SET @newVersion = '2.2.1.14';

			CREATE TABLE [dbo].[word_data_ve](
			[WORD_ID] [int] NOT NULL,
			[WORD_NAME] [nvarchar](255)  NULL
			) ON [PRIMARY]
            
			CREATE TABLE [dbo].[macro_data_ve](
			[MACRO_ID] [int] NOT NULL,
			[MACRO_NAME] [nvarchar](255)  NULL
			) ON [PRIMARY]
            
			CREATE TABLE [dbo].[alternate_word_index_ve](
	        [ID] [int] IDENTITY(1,1) NOT NULL,
	        [ALTERNATE_ID] [int] NOT NULL,
	        [WORD_ID] [int] NULL
            ) ON [PRIMARY]
            
			CREATE TABLE [dbo].[alternate_macro_index_ve](
	        [ID] [int] IDENTITY(1,1) NOT NULL,
	        [ALTERNATE_ID] [int] NOT NULL,
	        [MACRO_ID] [int] NULL
            ) ON [PRIMARY]
            
			CREATE TABLE [dbo].[answer_word_index_ve](
	        [ID] [int] IDENTITY(1,1) NOT NULL,
	        [ANSWER_ID] [int] NOT NULL,
	        [WORD_ID] [int] NULL
            ) ON [PRIMARY]
            
			CREATE TABLE [dbo].[answer_macro_index_ve](
	        [ID] [int] IDENTITY(1,1) NOT NULL,
	        [ANSWER_ID] [int] NOT NULL,
	        [MACRO_ID] [int] NULL
            ) ON [PRIMARY]
            
			CREATE TABLE [dbo].[macro_hash_ve](
	        [MACRO_ID] [int] NOT NULL,
	        [MACRO_HASH] [nvarchar](255)  NULL
            ) ON [PRIMARY]
            
			CREATE TABLE [dbo].[answer_hash_ve](
	        [ANSWER_ID] [int] NOT NULL,
	        [ANSWER_HASH] [nvarchar](255)  NULL
            ) ON [PRIMARY]
            
            CREATE TABLE [dbo].[alternate_hash_ve](
	        [ALTERNATE_ID] [int] NOT NULL,
	        [ALTERNATE_HASH] [nvarchar](255)  NULL
            ) ON [PRIMARY]
			
			DROP TABLE [dbo].[macro_index_status]
			CREATE TABLE [dbo].[macro_index_status](
				[id] [int] IDENTITY(2,1) NOT NULL,
				[vengine_memory_write] [smallint] NULL,
				[vengine_write] [smallint] NULL,
				[vportal_read] [smallint] NULL,
				[swap_lock] [smallint] NULL,
				[swap_ready] [smallint] NULL,
				[publish_request] [smallint] NULL, 
				[VENGINE_LAST_WRITE_TS] [datetime] NULL,
				[VPORTAL_LAST_READ_TS] [datetime] NULL,
				[VPORTAL_READ_SETBYVENGINE] [smallint] NULL
			) ON [PRIMARY]
			
			DBCC CHECKIDENT ('[dbo].[macro_index_status]', RESEED, 1);
            
			UPDATE [dbo].[engine_version] SET VERSION = @newVersion;
		END
	ELSE		
		SELECT 'Script failed due to invalid local database version' as 'Result', @expectedVersion as 'Expected Version', @currentVersion as 'Current Version';		
END
GO
	
EXECUTE dbo.verifyDBVerAndUpdateScript;
GO
DROP PROCEDURE dbo.verifyDBVerAndUpdateScript;
GO

CREATE PROCEDURE insertDefaultMIStatus	
AS
BEGIN
	DECLARE @expectedVersion varchar(50);	
	DECLARE @currentVersion varchar(50);	
	DECLARE @countRows smallint;
	SET @expectedVersion = '2.2.1.14';
	SET @currentVersion = (SELECT vv.VERSION FROM dbo.engine_version vv);	    
    SET @countRows = (SELECT count(*) FROM dbo.macro_index_status);
	IF @currentVersion = @expectedVersion AND @countRows = 0			
		BEGIN			
			INSERT INTO [dbo].[macro_index_status](vengine_memory_write,vengine_write,vportal_read,swap_lock,swap_ready,publish_request,VENGINE_LAST_WRITE_TS,VPORTAL_LAST_READ_TS,VPORTAL_READ_SETBYVENGINE) 
			VALUES(0,0,0,0,0,0,GETDATE(),GETDATE(),1);
		END
	ELSE
		SELECT 'Script failed due to invalid local database version or Row already exists';		
END
GO

EXECUTE dbo.insertDefaultMIStatus;
GO
DROP PROCEDURE dbo.insertDefaultMIStatus;
GO

CREATE PROCEDURE swapMIData	
AS
BEGIN	
	DECLARE @swap_ready_flag smallint;
	DECLARE @swap_lock_flag smallint;
	SET @swap_ready_flag = (SELECT mistatus.swap_ready  FROM [dbo].[macro_index_status] mistatus);
	SET @swap_lock_flag = (SELECT mistatus.swap_lock  FROM [dbo].[macro_index_status] mistatus);
	
	IF @swap_lock_flag = 0 and @swap_ready_flag = 1
		BEGIN
			UPDATE [dbo].[macro_index_status] SET swap_lock = 1;			
			
			DROP TABLE [dbo].[alternate_hash];
			DROP TABLE [dbo].[answer_hash];
			DROP TABLE [dbo].[macro_hash];
			DROP TABLE [dbo].[macro_data];
			DROP TABLE [dbo].[word_data];
			DROP TABLE [dbo].[alternate_macro_index];
			DROP TABLE [dbo].[alternate_word_index];
			DROP TABLE [dbo].[answer_macro_index];
			DROP TABLE [dbo].[answer_word_index];			

			EXEC sp_rename 'alternate_hash_ve','alternate_hash';
			EXEC sp_rename 'answer_hash_ve','answer_hash';
			EXEC sp_rename 'macro_hash_ve','macro_hash';
			EXEC sp_rename 'macro_data_ve','macro_data';
			EXEC sp_rename 'word_data_ve','word_data';
			EXEC sp_rename 'alternate_macro_index_ve','alternate_macro_index';
			EXEC sp_rename 'alternate_word_index_ve','alternate_word_index';
			EXEC sp_rename 'answer_macro_index_ve','answer_macro_index';
			EXEC sp_rename 'answer_word_index_ve','answer_word_index';							
					
			CREATE TABLE [dbo].[alternate_hash_ve](
				[ALTERNATE_ID] [int] NOT NULL,
				[ALTERNATE_HASH] [nvarchar](255)  NULL
			) ON [PRIMARY]			

			CREATE TABLE [dbo].[macro_hash_ve](
				[MACRO_ID] [int] NOT NULL,
				[MACRO_HASH] [nvarchar](255)  NULL
			) ON [PRIMARY]
					
			CREATE TABLE [dbo].[answer_hash_ve](
				[ANSWER_ID] [int] NOT NULL,
				[ANSWER_HASH] [nvarchar](255)  NULL
			) ON [PRIMARY]		
						
			CREATE TABLE [dbo].[alternate_macro_index_ve](
				[ID] [int] IDENTITY(1,1) NOT NULL,
				[ALTERNATE_ID] [int] NOT NULL,
				[MACRO_ID] [int] NULL
			) ON [PRIMARY]
					
			CREATE TABLE [dbo].[alternate_word_index_ve](
				[ID] [int] IDENTITY(1,1) NOT NULL,
				[ALTERNATE_ID] [int] NOT NULL,
				[WORD_ID] [int] NULL
			) ON [PRIMARY]
			
			CREATE TABLE [dbo].[answer_macro_index_ve](
				[ID] [int] IDENTITY(1,1) NOT NULL,
				[ANSWER_ID] [int] NOT NULL,
				[MACRO_ID] [int] NULL
			) ON [PRIMARY]
			
			CREATE TABLE [dbo].[answer_word_index_ve](
				[ID] [int] IDENTITY(1,1) NOT NULL,
				[ANSWER_ID] [int] NOT NULL,
				[WORD_ID] [int] NULL
			) ON [PRIMARY]
			
			CREATE TABLE [dbo].[word_data_ve](
				[WORD_ID] [int] NOT NULL,
				[WORD_NAME] [nvarchar](255)  NULL
			) ON [PRIMARY]
			
			CREATE TABLE [dbo].[macro_data_ve](
				[MACRO_ID] [int] NOT NULL,
				[MACRO_NAME] [nvarchar](255)  NULL
			) ON [PRIMARY]			

			UPDATE [dbo].[macro_index_status] SET swap_ready = 0;
			UPDATE [dbo].[macro_index_status] SET swap_lock = 0;
			
			SELECT 'swap mi data successful' as "Result";
		END
	ELSE		
		IF @swap_lock_flag = 1
			SELECT 'Can not swap mi data as swap lock is already held' as "Result";		
		ELSE
			SELECT 'Can not swap mi data as mi data is not swap ready' as "Result";		
END
GO
