USE [enginedb];
GO

-- VP-3300 & 3301
IF NOT EXISTS (
	SELECT * 
	FROM   sys.columns 
	WHERE  object_id = OBJECT_ID(N'[dbo].[transinfo]') 
         AND name = 'SOURCE'
	)
	ALTER TABLE [dbo].[transinfo] ADD [SOURCE] [nvarchar](255) NOT NULL DEFAULT (N'UI_VA');
GO

IF NOT EXISTS (
	SELECT * 
	FROM   sys.columns 
	WHERE  object_id = OBJECT_ID(N'[dbo].[transinfo]') 
         AND name = 'USER_ID'
	)
	BEGIN
		ALTER TABLE [dbo].[transinfo] ADD [USER_ID] [nvarchar](255) NULL;	
		ALTER TABLE [dbo].[transinfo] ADD  DEFAULT (NULL) FOR [USER_ID];	
	END
GO

IF NOT EXISTS (
	SELECT * 
	FROM   sys.columns 
	WHERE  object_id = OBJECT_ID(N'[dbo].[transinfo]') 
         AND name = 'USER_FULL_NAME'
	)
	BEGIN
		ALTER TABLE [dbo].[transinfo] ADD [USER_FULL_NAME] [nvarchar](255) NULL;	
		ALTER TABLE [dbo].[transinfo] ADD  DEFAULT (NULL) FOR [USER_FULL_NAME];	
	END	
GO


IF NOT EXISTS (
	SELECT * 
	FROM   sys.columns 
	WHERE  object_id = OBJECT_ID(N'[dbo].[transinfo]') 
         AND name = 'SUGGESTED_ANSWER'
	)
	BEGIN
		ALTER TABLE [dbo].[transinfo] ADD [SUGGESTED_ANSWER] [nvarchar](MAX) NULL;	
		ALTER TABLE [dbo].[transinfo] ADD  DEFAULT (NULL) FOR [SUGGESTED_ANSWER];	
	END
GO

-- Data-type of ANSWER_TEXT column changed for multilingual answer text
ALTER TABLE dbo.dynamic_answer_dtl ALTER COLUMN ANSWER_TEXT nvarchar(max) NULL;
GO

-- VP-2694
ALTER TABLE [dbo].[transinfo] ADD [REQUEST_SUBTYPE] [nvarchar](255) NULL;
GO
ALTER TABLE [dbo].[transinfo] ADD [REQUEST_SOURCE] [nvarchar](255) NULL;
GO

-- VP-2323
ALTER TABLE [dbo].[activitylog] ADD [ENGINEID] [nvarchar] (255) NOT NULL DEFAULT (N'');
GO
ALTER TABLE [dbo].[convinfo] ADD [ENGINEID] [nvarchar] (255) NOT NULL DEFAULT (N'');
GO
ALTER TABLE [dbo].[dw_hitsbyans] ADD [ENGINEID] [nvarchar] (255) NOT NULL DEFAULT (N'');
GO
ALTER TABLE [dbo].[dw_hitsbyans] DROP CONSTRAINT PK_dw_hitsbyans_ANSWERID;
GO
ALTER TABLE [dbo].[dw_hitsbyans] ADD CONSTRAINT PK_dw_hitsbyans_ANSWERID PRIMARY KEY CLUSTERED
(
	[ANSWERID] ASC,
	[BUSINESS_AREA] ASC,
	[START_DATE] ASC,
	[ENGINEID] ASC
);
GO
ALTER TABLE [dbo].[journeyinfo] ADD [ENGINEID] [nvarchar] (255) NOT NULL DEFAULT (N'');
GO
ALTER TABLE [dbo].[journeystepinfo] ADD [ENGINEID] [nvarchar] (255) NOT NULL DEFAULT (N'');
GO
ALTER TABLE [dbo].[stats_convtrans] ADD [ENGINEID] [nvarchar] (255) NOT NULL DEFAULT (N'');
GO
ALTER TABLE [dbo].[stats_convtrans] DROP CONSTRAINT stats_convtrans$STARTDATE_BUSINESSAREA_CHANNEL;
GO
ALTER TABLE [dbo].[stats_convtrans] ADD CONSTRAINT [stats_convtrans$STARTDATE_BUSINESSAREA_CHANNEL] UNIQUE NONCLUSTERED 
(
	[START_DATE] ASC,
	[BUSINESS_AREA] ASC,
	[CHANNEL] ASC,
	[ENGINEID] ASC
);
GO
ALTER TABLE [dbo].[survey] ADD [ENGINEID] [nvarchar] (255) NOT NULL DEFAULT (N'');
GO
ALTER TABLE [dbo].[transinfo] ADD [ENGINEID] [nvarchar] (255) NOT NULL DEFAULT (N'');
GO
