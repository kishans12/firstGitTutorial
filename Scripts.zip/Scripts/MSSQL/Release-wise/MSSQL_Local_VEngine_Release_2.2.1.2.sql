USE [enginedb];
GO

-- VP-3624
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[engine_version](
	[VERSION] [varchar](10)
) 

INSERT INTO [dbo].engine_version (VERSION) VALUES ('2.2.1.2');
GO