-- Modified for VP-3056 STARTS
USE [enginedb];
-- Modified for VP-3056 ENDS

INSERT INTO AGGREGATEDATA_K VALUES ('TOTANSCNT', 'A = Answer Count from transaction table');
INSERT INTO AGGREGATEDATA_K VALUES ('TOTICSCNT', 'B = Transaction Count for all answers with ICS ID NOT NULL');
INSERT INTO AGGREGATEDATA_K VALUES ('ICSTRANSCNT', 'C= Transaction Count for a particular Answer with ICS ID NOT NULL');
INSERT INTO AGGREGATEDATA_K VALUES ('TOTHELPFULCNT', 'D = Count for a particular Answer where KEY is �HELPFUL�');
INSERT INTO AGGREGATEDATA_K VALUES ('ACTHELPFULCNT', 'E = Count for a particular Answer where KEY is �HELPFUL� and VALUE is �YES�');
INSERT INTO AGGREGATEDATA_K VALUES ('ACTSAVECALLCNT', 'F = Count for a particular Answer where KEY is �SAVE-CALL �  and VALUE is �YES�');
INSERT INTO AGGREGATEDATA_K VALUES ('TOTSAVECALLCNT', 'G = Count for a particular Answer where KEY is �SAVE-CALL�');
INSERT INTO AGGREGATEDATA_K VALUES ('TRANSCNT', 'H = Transaction Count for a particular Answer');

