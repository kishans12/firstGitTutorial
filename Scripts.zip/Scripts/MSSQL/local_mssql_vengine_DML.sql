USE [enginedb];
GO
INSERT INTO [dbo].engine_version (VERSION) VALUES ('2.2.1.14');
GO
INSERT INTO macro_index_status(vengine_memory_write,vengine_write,vportal_read,swap_lock,swap_ready,publish_request,VENGINE_LAST_WRITE_TS,VPORTAL_LAST_READ_TS,VPORTAL_READ_SETBYVENGINE) VALUES(0,0,0,0,0,0,GETDATE(),GETDATE(),1);
GO
