-- Drop VPortal Database
-- Modified for VP-2569 STARTS
-- DROP DATABASE IF EXISTS enginedbnappr_221;
-- Modified for VP-2569 ENDS

-- Create VPortal Database
CREATE DATABASE IF NOT EXISTS enginedbnappr_221 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE enginedbnappr_221;

-- ----------------------------
-- Table structure for DynamicAnswer
-- ----------------------------
DROP TABLE IF EXISTS dynamic_answer_dtl;
CREATE TABLE dynamic_answer_dtl (
  ANSWERID int(11) NOT NULL,
  ANSWER_TEXT LONGTEXT DEFAULT NULL,
  SUPPRESS_FLG tinyint(4) DEFAULT NULL,
  VERSION varchar(191) NOT NULL DEFAULT '',
  PRIMARY KEY (ANSWERID,VERSION)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for engine_startup_info
-- ----------------------------
DROP TABLE IF EXISTS engine_startup_info;
CREATE TABLE engine_startup_info (
  NSCONTEXT varchar(255) DEFAULT NULL,
  POANAME varchar(255) DEFAULT NULL,
  DATE date DEFAULT NULL,
  TIME time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for alternate_hash
-- ----------------------------
DROP TABLE IF EXISTS alternate_hash;
CREATE TABLE alternate_hash (
  ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
  ALTERNATE_HASH varchar(255) DEFAULT NULL,
  PRIMARY KEY (ALTERNATE_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------
-- Table structure for alternate_hash_ve
-- --------------------------------------------
DROP TABLE IF EXISTS alternate_hash_ve;
CREATE TABLE alternate_hash_ve (
  ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
  ALTERNATE_HASH varchar(255) DEFAULT NULL,
  PRIMARY KEY (ALTERNATE_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for alternate_macro_index
-- ----------------------------
DROP TABLE IF EXISTS alternate_macro_index;
CREATE TABLE alternate_macro_index (
  ID int(11) NOT NULL AUTO_INCREMENT,
  ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
  MACRO_ID int(11) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- ---------------------------------------------------
-- Table structure for alternate_macro_index_ve
-- ---------------------------------------------------
DROP TABLE IF EXISTS alternate_macro_index_ve;
CREATE TABLE alternate_macro_index_ve (
  ID int(11) NOT NULL AUTO_INCREMENT,
  ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
  MACRO_ID int(11) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for alternate_word_index
-- ----------------------------
DROP TABLE IF EXISTS alternate_word_index;
CREATE TABLE alternate_word_index (
  ID int(11) NOT NULL AUTO_INCREMENT,
  ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
  WORD_ID int(11) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------------
-- Table structure for alternate_word_index_ve
-- --------------------------------------------
DROP TABLE IF EXISTS alternate_word_index_ve;
CREATE TABLE alternate_word_index_ve (
  ID int(11) NOT NULL AUTO_INCREMENT,
  ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
  WORD_ID int(11) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for answer_hash
-- ----------------------------
DROP TABLE IF EXISTS answer_hash;
CREATE TABLE answer_hash (
  ANSWER_ID int(11) NOT NULL DEFAULT '0',
  ANSWER_HASH varchar(255) DEFAULT NULL,
  PRIMARY KEY (ANSWER_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for answer_hash_ve
-- ----------------------------
DROP TABLE IF EXISTS answer_hash_ve;
CREATE TABLE answer_hash_ve (
  ANSWER_ID int(11) NOT NULL DEFAULT '0',
  ANSWER_HASH varchar(255) DEFAULT NULL,
  PRIMARY KEY (ANSWER_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for answer_macro_index
-- ----------------------------
DROP TABLE IF EXISTS answer_macro_index;
CREATE TABLE answer_macro_index (
  ID int(11) NOT NULL AUTO_INCREMENT,
  ANSWER_ID int(11) NOT NULL DEFAULT '0',
  MACRO_ID int(11) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- --------------------------------------
-- Table structure for answer_macro_index_ve
-- --------------------------------------
DROP TABLE IF EXISTS answer_macro_index_ve;
CREATE TABLE answer_macro_index_ve (
  ID int(11) NOT NULL AUTO_INCREMENT,
  ANSWER_ID int(11) NOT NULL DEFAULT '0',
  MACRO_ID int(11) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for answer_word_index
-- ----------------------------
DROP TABLE IF EXISTS answer_word_index;
CREATE TABLE answer_word_index (
  ID int(11) NOT NULL AUTO_INCREMENT,
  ANSWER_ID int(11) NOT NULL DEFAULT '0',
  WORD_ID int(11) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for answer_word_index_ve
-- ----------------------------
DROP TABLE IF EXISTS answer_word_index_ve;
CREATE TABLE answer_word_index_ve (
  ID int(11) NOT NULL AUTO_INCREMENT,
  ANSWER_ID int(11) NOT NULL DEFAULT '0',
  WORD_ID int(11) DEFAULT NULL,
  PRIMARY KEY (ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for macro_data
-- ----------------------------
DROP TABLE IF EXISTS macro_data;
CREATE TABLE macro_data (
  MACRO_ID int(11) NOT NULL DEFAULT '0',
  MACRO_NAME varchar(255) DEFAULT NULL,
  PRIMARY KEY (MACRO_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------
-- Table structure for macro_data_ve
-- ------------------------------------------
DROP TABLE IF EXISTS macro_data_ve;
CREATE TABLE macro_data_ve (
  MACRO_ID int(11) NOT NULL DEFAULT '0',
  MACRO_NAME varchar(255) DEFAULT NULL,
  PRIMARY KEY (MACRO_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for macro_hash
-- ----------------------------
DROP TABLE IF EXISTS macro_hash;
CREATE TABLE macro_hash (
  MACRO_ID int(11) NOT NULL DEFAULT '0',
  MACRO_HASH varchar(255) DEFAULT NULL,
  PRIMARY KEY (MACRO_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for macro_hash_ve
-- ----------------------------
DROP TABLE IF EXISTS macro_hash_ve;
CREATE TABLE macro_hash_ve (
  MACRO_ID int(11) NOT NULL DEFAULT '0',
  MACRO_HASH varchar(255) DEFAULT NULL,
  PRIMARY KEY (MACRO_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for word_data
-- ----------------------------
DROP TABLE IF EXISTS word_data;
CREATE TABLE word_data (
  WORD_ID int(11) NOT NULL DEFAULT '0',
  WORD_NAME varchar(255) DEFAULT NULL,
  PRIMARY KEY (WORD_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ---------------------------------------
-- Table structure for word_data_ve
-- ---------------------------------------
DROP TABLE IF EXISTS word_data_ve;
CREATE TABLE word_data_ve (
  WORD_ID int(11) NOT NULL DEFAULT '0',
  WORD_NAME varchar(255) DEFAULT NULL,
  PRIMARY KEY (WORD_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for macro_index_status
-- ----------------------------
DROP TABLE IF EXISTS macro_index_status;
CREATE TABLE macro_index_status (
  id int(11) NOT NULL AUTO_INCREMENT,
  vengine_memory_write tinyint(1) DEFAULT '0',
  vengine_write tinyint(1) DEFAULT '0',
  vportal_read tinyint(1) DEFAULT '0',
  swap_lock tinyint(1) DEFAULT '0',
  swap_ready tinyint(1) DEFAULT '0',
  publish_request tinyint(1) DEFAULT '0',
  VENGINE_LAST_WRITE_TS timestamp NULL DEFAULT NULL,
  VPORTAL_LAST_READ_TS timestamp NULL DEFAULT NULL,
  VPORTAL_READ_SETBYVENGINE tinyint(1) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- AUTOCOMPLETE INDEX TABLE STARTS

-- --------------------------------------
-- Table structure for  ac_alternate_hash
-- --------------------------------------
CREATE TABLE IF NOT EXISTS `ac_alternate_hash` (
  `ALTERNATE_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `ALTERNATE_HASH` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ALTERNATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------
-- Table structure for ac_answer_que_hash
-- --------------------------------------
CREATE TABLE IF NOT EXISTS `ac_answer_que_hash` (
  `ANSWER_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `ANSWER_QUESTION_HASH` varchar(255)  DEFAULT NULL,
  PRIMARY KEY (`ANSWER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------
-- Table structure for ac_answer_que_word_index
-- --------------------------------------------
CREATE TABLE IF NOT EXISTS `ac_answer_que_word_index` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ANSWER_ID` int(11) NOT NULL,
  `WORD_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------------------------
-- Table structure for ac_condition_alt_word_index
-- -----------------------------------------------
CREATE TABLE IF NOT EXISTS `ac_condition_alt_word_index` (
  `ALTERNATE_ID` int(11) NOT NULL,
  `WORD_ID` int(11) DEFAULT NULL,
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -----------------------------------------
-- Table structure for table ac_index_status
-- -----------------------------------------
CREATE TABLE IF NOT EXISTS `ac_index_status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vengine_write` tinyint(4) DEFAULT '0',
  `vportal_read` tinyint(4) DEFAULT '0',
  `VENGINE_LAST_WRITE_TS` timestamp NULL DEFAULT NULL,
  `VPORTAL_LAST_READ_TS` timestamp NULL DEFAULT NULL,
  `VPORTAL_READ_SETBYVENGINE` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -------------------------------------------------
-- Table structure for ac_recognition_alt_word_index
-- -------------------------------------------------
CREATE TABLE IF NOT EXISTS `ac_recognition_alt_word_index` (
  `ALTERNATE_ID` int(11) NOT NULL,
  `WORD_ID` int(11) DEFAULT NULL,
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -------------------------------------------
-- Table structure for ac_recognition_que_hash
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `ac_recognition_que_hash` (
  `RECOGNITION_ID` int(11) unsigned NOT NULL DEFAULT '0',
  `RECOGNITION_HASH` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`RECOGNITION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- -------------------------------------------------
-- Table structure for ac_recognition_que_word_index
-- -------------------------------------------------
CREATE TABLE IF NOT EXISTS `ac_recognition_que_word_index` (
  `ID` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `RECOGNITION_ID` int(11) NOT NULL,
  `WORD_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------
-- Table structure for ac_word_data
-- --------------------------------
CREATE TABLE IF NOT EXISTS `ac_word_data` (
  `WORD_ID` int(11) NOT NULL DEFAULT '0',
  `WORD_NAME` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`WORD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- AUTOCOMPLETE INDEX TABLE ENDS


-- VP-3624
CREATE TABLE engine_version (
	VERSION VARCHAR(10) NOT NULL
)   ENGINE=InnoDB DEFAULT CHARSET=utf8;


DELIMITER $$

DROP PROCEDURE IF EXISTS swapMIData$$

CREATE PROCEDURE swapMIData()
BEGIN

	SET @swap_ready_flag = (SELECT mistatus.swap_ready  FROM macro_index_status mistatus);
	SET @swap_lock_flag = (SELECT mistatus.swap_lock  FROM macro_index_status mistatus);
	
	IF @swap_lock_flag = 0 and @swap_ready_flag = 1 THEN		
		UPDATE macro_index_status SET swap_lock = 1 WHERE ID = 1;
		
		-- DROP tables
		DROP TABLE IF EXISTS alternate_hash;
		DROP TABLE IF EXISTS answer_hash;
		DROP TABLE IF EXISTS macro_hash;
		DROP TABLE IF EXISTS macro_data;
		DROP TABLE IF EXISTS word_data;
		DROP TABLE IF EXISTS alternate_macro_index;
		DROP TABLE IF EXISTS alternate_word_index;
		DROP TABLE IF EXISTS answer_macro_index;
		DROP TABLE IF EXISTS answer_word_index;
		
		-- Rename tables
		RENAME TABLE alternate_hash_ve TO alternate_hash;
		RENAME TABLE answer_hash_ve TO answer_hash;
		RENAME TABLE macro_hash_ve TO macro_hash;
		RENAME TABLE macro_data_ve TO macro_data;
		RENAME TABLE word_data_ve TO word_data;
		RENAME TABLE alternate_macro_index_ve TO alternate_macro_index;
		RENAME TABLE alternate_word_index_ve TO alternate_word_index;
		RENAME TABLE answer_macro_index_ve TO answer_macro_index;
		RENAME TABLE answer_word_index_ve TO answer_word_index;
		
		-- Create tables	
		CREATE TABLE alternate_hash_ve (
			ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
			ALTERNATE_HASH varchar(255) DEFAULT NULL,
			PRIMARY KEY (ALTERNATE_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		
		CREATE TABLE answer_hash_ve (
			ANSWER_ID int(11) NOT NULL DEFAULT '0',
			ANSWER_HASH varchar(255) DEFAULT NULL,
			PRIMARY KEY (ANSWER_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		
		CREATE TABLE macro_hash_ve (	
			MACRO_ID int(11) NOT NULL DEFAULT '0',
			MACRO_HASH varchar(255) DEFAULT NULL,
			PRIMARY KEY (MACRO_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;	
		
		CREATE TABLE macro_data_ve (
			MACRO_ID int(11) NOT NULL DEFAULT '0',
			MACRO_NAME varchar(255) DEFAULT NULL,
			PRIMARY KEY (MACRO_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
		
		CREATE TABLE word_data_ve (
			WORD_ID int(11) NOT NULL DEFAULT '0',
			WORD_NAME varchar(255) DEFAULT NULL,
			PRIMARY KEY (WORD_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

		CREATE TABLE alternate_macro_index_ve (
		  ID int(11) NOT NULL AUTO_INCREMENT,
		  ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
		  MACRO_ID int(11) DEFAULT NULL,
		  PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		CREATE TABLE alternate_word_index_ve (
			ID int(11) NOT NULL AUTO_INCREMENT,
			ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
			WORD_ID int(11) DEFAULT NULL,
			PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;	

		CREATE TABLE answer_macro_index_ve (
			ID int(11) NOT NULL AUTO_INCREMENT,
			ANSWER_ID int(11) NOT NULL DEFAULT '0',
			MACRO_ID int(11) DEFAULT NULL,
			PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		CREATE TABLE answer_word_index_ve (
			ID int(11) NOT NULL AUTO_INCREMENT,
			ANSWER_ID int(11) NOT NULL DEFAULT '0',
			WORD_ID int(11) DEFAULT NULL,
			PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		
		UPDATE macro_index_status SET swap_ready = 0 WHERE ID = 1;
		UPDATE macro_index_status SET swap_lock = 0 WHERE ID = 1;
		
		SELECT 'swap mi data successful' as "Result";
	ELSE		
		IF @swap_lock_flag = 1 THEN
			SELECT 'Can not swap mi data as swap lock is already held' as "Result";		
		ELSE
			SELECT 'Can not swap mi data as mi data is not swap ready' as "Result";		
		END IF;
	END IF;

END $$

DELIMITER ;