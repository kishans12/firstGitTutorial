-- Modified for VP-3056 STARTS
USE enginedbnappr_221;
-- Modified for VP-3056 ENDS

-- ----------------------------
-- Records of aggregatedata_k
-- ----------------------------
INSERT INTO aggregatedata_k VALUES ('TOTANSCNT', 'A = Answer Count from transaction table');
INSERT INTO aggregatedata_k VALUES ('TOTICSCNT', 'B = Transaction Count for all answers with ICS ID NOT NULL');
INSERT INTO aggregatedata_k VALUES ('ICSTRANSCNT', 'C= Transaction Count for a particular Answer with ICS ID NOT NULL');
INSERT INTO aggregatedata_k VALUES ('TOTHELPFULCNT', 'D = Count for a particular Answer where KEY is �HELPFUL�');
INSERT INTO aggregatedata_k VALUES ('ACTHELPFULCNT', 'E = Count for a particular Answer where KEY is �HELPFUL� and VALUE is �YES�');
INSERT INTO aggregatedata_k VALUES ('ACTSAVECALLCNT', 'F = Count for a particular Answer where KEY is �SAVE-CALL �  and VALUE is �YES�');
INSERT INTO aggregatedata_k VALUES ('TOTSAVECALLCNT', 'G = Count for a particular Answer where KEY is �SAVE-CALL�');
INSERT INTO aggregatedata_k VALUES ('TRANSCNT', 'H = Transaction Count for a particular Answer');
