USE enginedb;

DELIMITER $$

CREATE PROCEDURE verifyDBVerAndUpdateScript()
BEGIN

	DECLARE expectedVersion varchar(50);
	DECLARE newVersion varchar(50);
	DECLARE currentVersion varchar(50);

	SET @expectedVersion = "2.2.1.2";
	SET @newVersion = "2.2.1.14";

	SET @currentVersion = (SELECT vv.VERSION  FROM engine_version vv);

	if @currentVersion = @expectedVersion then
	   
		CREATE TABLE word_data_ve (
		WORD_ID int(11) NOT NULL DEFAULT '0',
		WORD_NAME varchar(255) DEFAULT NULL,
		PRIMARY KEY (WORD_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
  
		CREATE TABLE macro_data_ve (
		MACRO_ID int(11) NOT NULL DEFAULT '0',
		MACRO_NAME varchar(255) DEFAULT NULL,
		PRIMARY KEY (MACRO_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

		CREATE TABLE alternate_word_index_ve (
		ID int(11) NOT NULL AUTO_INCREMENT,
		ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
		WORD_ID int(11) DEFAULT NULL,
		PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
     
		CREATE TABLE alternate_macro_index_ve (
		ID int(11) NOT NULL AUTO_INCREMENT,
		ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
		MACRO_ID int(11) DEFAULT NULL,
		PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		CREATE TABLE answer_word_index_ve (
		ID int(11) NOT NULL AUTO_INCREMENT,
		ANSWER_ID int(11) NOT NULL DEFAULT '0',
		WORD_ID int(11) DEFAULT NULL,
		PRIMARY KEY (ID)
		)ENGINE=InnoDB DEFAULT CHARSET=utf8;

		CREATE TABLE answer_macro_index_ve (
		ID int(11) NOT NULL AUTO_INCREMENT,
		ANSWER_ID int(11) NOT NULL DEFAULT '0',
		MACRO_ID int(11) DEFAULT NULL,
		PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		CREATE TABLE macro_hash_ve (
		MACRO_ID int(11) NOT NULL DEFAULT '0',
		MACRO_HASH varchar(255) DEFAULT NULL,
		PRIMARY KEY (MACRO_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		CREATE TABLE answer_hash_ve(
		ANSWER_ID int(11) NOT NULL DEFAULT '0',
		ANSWER_HASH varchar(255) DEFAULT NULL,
		PRIMARY KEY (ANSWER_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;  

		CREATE TABLE alternate_hash_ve(
		ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
		ALTERNATE_HASH varchar(255) DEFAULT NULL,
		PRIMARY KEY (ALTERNATE_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		DROP TABLE IF EXISTS macro_index_status;
		CREATE TABLE macro_index_status (
		id int(11) NOT NULL AUTO_INCREMENT,
		vengine_memory_write tinyint(1) DEFAULT '0',
		vengine_write tinyint(1) DEFAULT '0',
		vportal_read tinyint(1) DEFAULT '0',
		swap_lock tinyint(1) DEFAULT '0',
		swap_ready tinyint(1) DEFAULT '0',
		publish_request tinyint(1) DEFAULT '0',
		VENGINE_LAST_WRITE_TS timestamp NULL DEFAULT NULL,
		VPORTAL_LAST_READ_TS timestamp NULL DEFAULT NULL,
		VPORTAL_READ_SETBYVENGINE tinyint(1) DEFAULT NULL,
		PRIMARY KEY (id)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		INSERT INTO macro_index_status(vengine_memory_write,vengine_write,vportal_read,swap_lock,swap_ready,publish_request,VENGINE_LAST_WRITE_TS,VPORTAL_LAST_READ_TS,VPORTAL_READ_SETBYVENGINE) 
		VALUES(0,0,0,0,0,0,CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,1);

		UPDATE engine_version SET VERSION = @newVersion;
	  
	else
		SELECT 'Script failed due to invalid local database version' as "Result", @expectedVersion as "Expected Version", @currentVersion as "Current Version";
	end if;

END $$

CALL verifyDBVerAndUpdateScript()$$
DROP PROCEDURE verifyDBVerAndUpdateScript $$

DROP PROCEDURE IF EXISTS swapMIData$$

CREATE PROCEDURE swapMIData()
BEGIN

	SET @swap_ready_flag = (SELECT mistatus.swap_ready  FROM macro_index_status mistatus);
	SET @swap_lock_flag = (SELECT mistatus.swap_lock  FROM macro_index_status mistatus);
	
	IF @swap_lock_flag = 0 and @swap_ready_flag = 1 THEN		
		UPDATE macro_index_status SET swap_lock = 1;
		
		-- DROP tables
		DROP TABLE IF EXISTS alternate_hash;
		DROP TABLE IF EXISTS answer_hash;
		DROP TABLE IF EXISTS macro_hash;
		DROP TABLE IF EXISTS macro_data;
		DROP TABLE IF EXISTS word_data;
		DROP TABLE IF EXISTS alternate_macro_index;
		DROP TABLE IF EXISTS alternate_word_index;
		DROP TABLE IF EXISTS answer_macro_index;
		DROP TABLE IF EXISTS answer_word_index;
		
		-- Rename tables
		RENAME TABLE alternate_hash_ve TO alternate_hash;
		RENAME TABLE answer_hash_ve TO answer_hash;
		RENAME TABLE macro_hash_ve TO macro_hash;
		RENAME TABLE macro_data_ve TO macro_data;
		RENAME TABLE word_data_ve TO word_data;
		RENAME TABLE alternate_macro_index_ve TO alternate_macro_index;
		RENAME TABLE alternate_word_index_ve TO alternate_word_index;
		RENAME TABLE answer_macro_index_ve TO answer_macro_index;
		RENAME TABLE answer_word_index_ve TO answer_word_index;
		
		-- Create tables	
		CREATE TABLE alternate_hash_ve (
			ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
			ALTERNATE_HASH varchar(255) DEFAULT NULL,
			PRIMARY KEY (ALTERNATE_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		
		CREATE TABLE answer_hash_ve (
			ANSWER_ID int(11) NOT NULL DEFAULT '0',
			ANSWER_HASH varchar(255) DEFAULT NULL,
			PRIMARY KEY (ANSWER_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
		
		CREATE TABLE macro_hash_ve (	
			MACRO_ID int(11) NOT NULL DEFAULT '0',
			MACRO_HASH varchar(255) DEFAULT NULL,
			PRIMARY KEY (MACRO_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;	
		
		CREATE TABLE macro_data_ve (
			MACRO_ID int(11) NOT NULL DEFAULT '0',
			MACRO_NAME varchar(255) DEFAULT NULL,
			PRIMARY KEY (MACRO_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
		
		CREATE TABLE word_data_ve (
			WORD_ID int(11) NOT NULL DEFAULT '0',
			WORD_NAME varchar(255) DEFAULT NULL,
			PRIMARY KEY (WORD_ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

		CREATE TABLE alternate_macro_index_ve (
		  ID int(11) NOT NULL AUTO_INCREMENT,
		  ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
		  MACRO_ID int(11) DEFAULT NULL,
		  PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		CREATE TABLE alternate_word_index_ve (
			ID int(11) NOT NULL AUTO_INCREMENT,
			ALTERNATE_ID int(11) NOT NULL DEFAULT '0',
			WORD_ID int(11) DEFAULT NULL,
			PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;	

		CREATE TABLE answer_macro_index_ve (
			ID int(11) NOT NULL AUTO_INCREMENT,
			ANSWER_ID int(11) NOT NULL DEFAULT '0',
			MACRO_ID int(11) DEFAULT NULL,
			PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;

		CREATE TABLE answer_word_index_ve (
			ID int(11) NOT NULL AUTO_INCREMENT,
			ANSWER_ID int(11) NOT NULL DEFAULT '0',
			WORD_ID int(11) DEFAULT NULL,
			PRIMARY KEY (ID)
		) ENGINE=InnoDB DEFAULT CHARSET=utf8;
				
		UPDATE macro_index_status SET swap_ready = 0;
		UPDATE macro_index_status SET swap_lock = 0;
		SELECT 'swap mi data successful' as "Result";	
	ELSE		
		IF @swap_lock_flag = 1 THEN
			SELECT 'Can not swap mi data as swap lock is already held' as "Result";		
		ELSE
			SELECT 'Can not swap mi data as mi data is not swap ready' as "Result";		
		END IF;
	END IF;

END $$

DELIMITER ;