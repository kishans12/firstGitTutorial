USE enginedb;

-- VP-3672
ALTER DATABASE enginedb CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci;
ALTER TABLE dynamic_answer_dtl CHANGE VERSION VERSION VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE dynamic_answer_dtl CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE macro_data CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE word_data CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE ac_word_data CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;