USE enginedb;

-- VP-3624
CREATE TABLE engine_version (
	VERSION VARCHAR(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO engine_version (VERSION) VALUES ('2.2.1.2');


