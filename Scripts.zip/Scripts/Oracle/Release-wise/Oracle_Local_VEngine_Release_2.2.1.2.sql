connect enginedb/enginedb;

-- VP-3624
CREATE TABLE engine_version (
	VERSION VARCHAR2(10) NOT NULL
);
INSERT INTO engine_version (VERSION) VALUES ('2.2.1.2');

