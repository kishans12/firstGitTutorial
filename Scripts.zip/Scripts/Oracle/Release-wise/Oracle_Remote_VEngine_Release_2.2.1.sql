connect enginedb/enginedb;

-- VP-3300 & 3301

DECLARE 
  v_column_exists number := 0;
BEGIN
 select count(*) INTO v_column_exists
  from ALL_TAB_COLUMNS 
  where COLUMN_NAME = 'SOURCE' AND TABLE_NAME='transinfo';
  
  IF (v_column_exists = 0) THEN     
    execute immediate 'ALTER TABLE transinfo ADD SOURCE VARCHAR(255) DEFAULT ''UI_VA''';
  END IF;
END;
/


DECLARE 
  v_column_exists number := 0;
BEGIN
 select count(*) INTO v_column_exists
  from ALL_TAB_COLUMNS 
  where COLUMN_NAME = 'USER_ID' AND TABLE_NAME='transinfo';
  
  IF (v_column_exists = 0) THEN     
    execute immediate 'ALTER TABLE transinfo ADD USER_ID VARCHAR(255) DEFAULT NULL';
  END IF;
END;
/

DECLARE 
  v_column_exists number := 0;
BEGIN
 select count(*) INTO v_column_exists
  from ALL_TAB_COLUMNS 
  where COLUMN_NAME = 'USER_FULL_NAME' AND TABLE_NAME='transinfo';
  
  IF (v_column_exists = 0) THEN     
    execute immediate 'ALTER TABLE transinfo ADD USER_FULL_NAME VARCHAR(255) DEFAULT NULL';
  END IF;
END;
/

DECLARE 
  v_column_exists number := 0;
BEGIN
 select count(*) INTO v_column_exists
  from ALL_TAB_COLUMNS 
  where COLUMN_NAME = 'SUGGESTED_ANSWER' AND TABLE_NAME='transinfo';
  
  IF (v_column_exists = 0) THEN     
    execute immediate 'ALTER TABLE transinfo ADD SUGGESTED_ANSWER CLOB DEFAULT NULL';
  END IF;
END;
/

-- VP-2694
ALTER TABLE transinfo ADD REQUEST_SUBTYPE VARCHAR(255) DEFAULT NULL;
ALTER TABLE transinfo ADD REQUEST_SOURCE VARCHAR(255) DEFAULT NULL;

-- VP-2323
ALTER TABLE activitylog ADD ENGINEID VARCHAR(255 CHAR) DEFAULT '';
ALTER TABLE convinfo ADD ENGINEID VARCHAR(255 CHAR) DEFAULT '';

ALTER TABLE dw_hitsbyans ADD ENGINEID VARCHAR(255 CHAR) DEFAULT '';
ALTER TABLE dw_hitsbyans DROP CONSTRAINT ANSWERID_BUSNESAREA_STARTDATE;
ALTER TABLE dw_hitsbyans
ADD CONSTRAINT ANSWERID_BUSNESAREA_STARTDATE UNIQUE (
  ANSWERID,
  BUSINESS_AREA,
  START_DATE,
  ENGINEID
)
ENABLE
;

ALTER TABLE journeyinfo ADD ENGINEID VARCHAR(255 CHAR) DEFAULT '';
ALTER TABLE journeystepinfo ADD ENGINEID VARCHAR(255 CHAR) DEFAULT '';

ALTER TABLE stats_convtrans ADD ENGINEID VARCHAR(255 CHAR) DEFAULT '';
ALTER TABLE stats_convtrans DROP CONSTRAINT STARTDATE_BUSINESSAREA_CHANNEL;
ALTER TABLE stats_convtrans ADD CONSTRAINT STARTDATE_BUSINESSAREA_CHANNEL UNIQUE (
  START_DATE,
  BUSINESS_AREA,
  CHANNEL,
  ENGINEID
)
ENABLE
;

ALTER TABLE survey ADD ENGINEID VARCHAR(255 CHAR) DEFAULT '';
ALTER TABLE transinfo ADD ENGINEID VARCHAR(255 CHAR) DEFAULT '';

