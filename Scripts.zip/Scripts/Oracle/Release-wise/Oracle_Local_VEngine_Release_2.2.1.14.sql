grant create sequence,create table,create trigger to enginedb;
connect enginedb/enginedb;

CREATE OR REPLACE PROCEDURE VERIFYDBVERANDUPDATESCRIPT 
IS
expectedVersion varchar2(50) := '2.2.1.2';
newVersion varchar2(50) := '2.2.1.14';
currentVersion varchar2(50) := '';    
  BEGIN    
    SELECT vv.VERSION INTO currentVersion FROM ENGINE_VERSION vv;
    IF currentVersion = expectedVersion then
      BEGIN
        EXECUTE IMMEDIATE ('CREATE TABLE word_data_ve (
        WORD_ID number(10) DEFAULT ''0'' NOT NULL,
        WORD_NAME varchar2(255) DEFAULT NULL,
        PRIMARY KEY (WORD_ID))');
      
        EXECUTE IMMEDIATE ('CREATE TABLE macro_data_ve (
          MACRO_ID number(10) DEFAULT ''0'' NOT NULL,
          MACRO_NAME varchar2(255) DEFAULT NULL,
          PRIMARY KEY (MACRO_ID))');
      
        EXECUTE IMMEDIATE ('CREATE TABLE alternate_word_index_ve (
          ID number(10) NOT NULL,
          ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
          WORD_ID number(10) DEFAULT NULL,
          PRIMARY KEY (ID))');
		 
        EXECUTE IMMEDIATE('CREATE SEQUENCE alternate_word_idx_ve_seq START WITH 1 INCREMENT BY 1');
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_word_idx_ve_seq_tr
BEFORE INSERT ON alternate_word_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_word_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
     
        EXECUTE IMMEDIATE ('CREATE TABLE alternate_macro_index_ve (
          ID number(10) NOT NULL,
          ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
          MACRO_ID number(10) DEFAULT NULL,
          PRIMARY KEY (ID))');
		  
        EXECUTE IMMEDIATE('CREATE SEQUENCE alternate_macro_idx_ve_seq START WITH 1 INCREMENT BY 1');	
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_macro_idx_ve_seq_tr
BEFORE INSERT ON alternate_macro_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_macro_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
	   
        EXECUTE IMMEDIATE ('CREATE TABLE answer_word_index_ve (
          ID number(10) NOT NULL,
          ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
          WORD_ID number(10) DEFAULT NULL,
          PRIMARY KEY (ID))');
		  
        EXECUTE IMMEDIATE('CREATE SEQUENCE answer_word_idx_ve_seq START WITH 1 INCREMENT BY 1');	
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_word_idx_ve_seq_tr
BEFORE INSERT ON answer_word_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_word_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
          
        EXECUTE IMMEDIATE ('CREATE TABLE answer_macro_index_ve (
          ID number(10) NOT NULL,
          ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
          MACRO_ID number(10) DEFAULT NULL,
          PRIMARY KEY (ID))') ;
		  
        EXECUTE IMMEDIATE('CREATE SEQUENCE answer_macro_idx_ve_seq START WITH 1 INCREMENT BY 1');		
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_macro_idx_ve_seq_tr
BEFORE INSERT ON answer_macro_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_macro_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');

        EXECUTE IMMEDIATE ('CREATE TABLE macro_hash_ve (
          MACRO_ID number(10) DEFAULT ''0'' NOT NULL,
          MACRO_HASH varchar2(255) DEFAULT NULL,
          PRIMARY KEY (MACRO_ID))') ;
          
        EXECUTE IMMEDIATE ('CREATE TABLE answer_hash_ve (
          ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
          ANSWER_HASH varchar2(255) DEFAULT NULL,
          PRIMARY KEY (ANSWER_ID))');
          
        EXECUTE IMMEDIATE ('CREATE TABLE alternate_hash_ve (
          ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
          ALTERNATE_HASH varchar2(255) DEFAULT NULL,
          PRIMARY KEY (ALTERNATE_ID))');
		
		EXECUTE IMMEDIATE('DROP TABLE MACRO_INDEX_STATUS');
		EXECUTE IMMEDIATE('DROP SEQUENCE macro_index_status_seq');
		
		EXECUTE IMMEDIATE('CREATE TABLE macro_index_status (
		  id number(10) NOT NULL,
		  vengine_memory_write number(3) DEFAULT ''0'',
		  vengine_write number(3) DEFAULT ''0'',
		  vportal_read number(3) DEFAULT ''0'',
		  swap_ready number(3) DEFAULT ''0'',
		  swap_lock number(3) DEFAULT ''0'',
		  publish_request number(3) DEFAULT ''0'',
		  VENGINE_LAST_WRITE_TS timestamp(0) DEFAULT NULL NULL,
		  VPORTAL_LAST_READ_TS timestamp(0) DEFAULT NULL NULL,
		  VPORTAL_READ_SETBYVENGINE number(3) DEFAULT NULL,
		  PRIMARY KEY (id)
		)');
		
		EXECUTE IMMEDIATE('CREATE SEQUENCE macro_index_status_seq START WITH 1 INCREMENT BY 1');
		
		EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER macro_index_status_seq_tr
BEFORE INSERT ON macro_index_status FOR EACH ROW
WHEN (NEW.id IS NULL)
BEGIN
  SELECT macro_index_status_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;');
		
		UPDATE engine_version SET VERSION = newVersion;
	  END;
	ELSE
      BEGIN  
        DBMS_OUTPUT.PUT_LINE('Script failed due to invalid local database version, Expected Version ' || expectedVersion || ', Current Version ' || currentVersion);
      END;
  END IF;
END VERIFYDBVERANDUPDATESCRIPT;
/

exec VERIFYDBVERANDUPDATESCRIPT();
DROP PROCEDURE VERIFYDBVERANDUPDATESCRIPT;

CREATE OR REPLACE PROCEDURE INSERTDEFAULTMISTATUS 
IS
expectedVersion varchar2(50) := '2.2.1.14';
currentVersion varchar2(50) := '';    
countRows number(3,0) := 0;
BEGIN    
	SELECT vv.VERSION INTO currentVersion FROM ENGINE_VERSION vv;
	SELECT count(*) INTO countRows FROM macro_index_status;
	IF currentVersion = expectedVersion AND countRows = 0 then
		BEGIN
			EXECUTE IMMEDIATE('INSERT INTO macro_index_status(vengine_memory_write,vengine_write,vportal_read,swap_lock,swap_ready,publish_request,VENGINE_LAST_WRITE_TS,VPORTAL_LAST_READ_TS,VPORTAL_READ_SETBYVENGINE) 
			VALUES(0,0,0,0,0,0,SYSDATE,SYSDATE,1)');
		END;
	ELSE
		BEGIN  
			DBMS_OUTPUT.PUT_LINE('Script failed due to invalid local database version or Row already exists');
		END;
	END IF;	
END INSERTDEFAULTMISTATUS;
/

exec INSERTDEFAULTMISTATUS();
DROP PROCEDURE INSERTDEFAULTMISTATUS;	

create or replace 
PROCEDURE swapMIData 
IS
swap_ready_flag NUMBER(3,0);
swap_lock_flag NUMBER(3,0);
BEGIN
  SELECT mistatus.swap_ready INTO swap_ready_flag FROM macro_index_status mistatus;
  SELECT mistatus.swap_lock INTO swap_lock_flag FROM macro_index_status mistatus;
      
    IF swap_lock_flag = 0 and swap_ready_flag = 1 then
      BEGIN
	  
        UPDATE macro_index_status SET swap_lock = 1;			
			
        EXECUTE IMMEDIATE('DROP TABLE alternate_hash');
        EXECUTE IMMEDIATE('DROP TABLE answer_hash');
        EXECUTE IMMEDIATE('DROP TABLE macro_hash');
        EXECUTE IMMEDIATE('DROP TABLE macro_data');
        EXECUTE IMMEDIATE('DROP TABLE word_data');
        EXECUTE IMMEDIATE('DROP TABLE alternate_macro_index');
        EXECUTE IMMEDIATE('DROP TABLE alternate_word_index');
        EXECUTE IMMEDIATE('DROP TABLE answer_macro_index');
        EXECUTE IMMEDIATE('DROP TABLE answer_word_index');		
        
        EXECUTE IMMEDIATE('ALTER TABLE alternate_hash_ve RENAME TO alternate_hash');
        EXECUTE IMMEDIATE('ALTER TABLE answer_hash_ve RENAME TO answer_hash');
        EXECUTE IMMEDIATE('ALTER TABLE macro_hash_ve RENAME TO macro_hash');
        EXECUTE IMMEDIATE('ALTER TABLE macro_data_ve RENAME TO macro_data');
        EXECUTE IMMEDIATE('ALTER TABLE word_data_ve RENAME TO word_data');
        EXECUTE IMMEDIATE('ALTER TABLE alternate_macro_index_ve RENAME TO alternate_macro_index');
        EXECUTE IMMEDIATE('ALTER TABLE alternate_word_index_ve RENAME TO alternate_word_index');
        EXECUTE IMMEDIATE('ALTER TABLE answer_macro_index_ve RENAME TO answer_macro_index');
        EXECUTE IMMEDIATE('ALTER TABLE answer_word_index_ve RENAME TO answer_word_index');        
        
        EXECUTE IMMEDIATE('DROP TRIGGER alternate_macro_idx_ve_seq_tr');
        EXECUTE IMMEDIATE('DROP TRIGGER alternate_word_idx_ve_seq_tr');
        EXECUTE IMMEDIATE('DROP TRIGGER answer_macro_idx_ve_seq_tr');
        EXECUTE IMMEDIATE('DROP TRIGGER answer_word_idx_ve_seq_tr');
		
		EXECUTE IMMEDIATE('DROP SEQUENCE alternate_macro_index_seq');
		EXECUTE IMMEDIATE('DROP SEQUENCE alternate_word_index_seq');
		EXECUTE IMMEDIATE('DROP SEQUENCE answer_macro_index_seq');
		EXECUTE IMMEDIATE('DROP SEQUENCE answer_word_index_seq');

		EXECUTE IMMEDIATE('RENAME alternate_macro_idx_ve_seq TO alternate_macro_index_seq');
		EXECUTE IMMEDIATE('RENAME alternate_word_idx_ve_seq TO alternate_word_index_seq');
		EXECUTE IMMEDIATE('RENAME answer_macro_idx_ve_seq TO answer_macro_index_seq');
		EXECUTE IMMEDIATE('RENAME answer_word_idx_ve_seq TO answer_word_index_seq');
		
		EXECUTE IMMEDIATE('CREATE SEQUENCE alternate_macro_idx_ve_seq START WITH 1 INCREMENT BY 1');
		EXECUTE IMMEDIATE('CREATE SEQUENCE alternate_word_idx_ve_seq START WITH 1 INCREMENT BY 1');
		EXECUTE IMMEDIATE('CREATE SEQUENCE answer_macro_idx_ve_seq START WITH 1 INCREMENT BY 1');
		EXECUTE IMMEDIATE('CREATE SEQUENCE answer_word_idx_ve_seq START WITH 1 INCREMENT BY 1');
     
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_macro_index_seq_tr
BEFORE INSERT ON alternate_macro_index FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_macro_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
                  
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_word_index_seq_tr
BEFORE INSERT ON alternate_word_index FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_word_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
    
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_macro_index_seq_tr
BEFORE INSERT ON answer_macro_index FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_macro_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
        
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_word_index_seq_tr
BEFORE INSERT ON answer_word_index FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_word_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
    
        EXECUTE IMMEDIATE('CREATE TABLE alternate_hash_ve (
                    ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
                    ALTERNATE_HASH varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (ALTERNATE_ID)
                  )');	
                  
        EXECUTE IMMEDIATE('CREATE TABLE answer_hash_ve (
                    ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
                    ANSWER_HASH varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (ANSWER_ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE TABLE macro_hash_ve (
                    MACRO_ID number(10) DEFAULT ''0'' NOT NULL,
                    MACRO_HASH varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (MACRO_ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE TABLE macro_data_ve (
                    MACRO_ID number(10) DEFAULT ''0'' NOT NULL,
                    MACRO_NAME varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (MACRO_ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE TABLE word_data_ve (
                    WORD_ID number(10) DEFAULT ''0'' NOT NULL,
                    WORD_NAME varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (WORD_ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE TABLE alternate_macro_index_ve (
                    ID number(10) NOT NULL,
                    ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
                    MACRO_ID number(10) DEFAULT NULL,
                    PRIMARY KEY (ID)
                  )');	
        
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_macro_idx_ve_seq_tr
BEFORE INSERT ON alternate_macro_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_macro_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
                  
        EXECUTE IMMEDIATE('CREATE TABLE alternate_word_index_ve (
                    ID number(10) NOT NULL,
                    ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
                    WORD_ID number(10) DEFAULT NULL,
                    PRIMARY KEY (ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_word_idx_ve_seq_tr
BEFORE INSERT ON alternate_word_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_word_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
    
        EXECUTE IMMEDIATE('CREATE TABLE answer_macro_index_ve (
                    ID number(10) NOT NULL,
                    ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
                    MACRO_ID number(10) DEFAULT NULL,
                    PRIMARY KEY (ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_macro_idx_ve_seq_tr
BEFORE INSERT ON answer_macro_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_macro_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
    
        EXECUTE IMMEDIATE('CREATE TABLE answer_word_index_ve (
                    ID number(10) NOT NULL,
                    ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
                    WORD_ID number(10) DEFAULT NULL,
                    PRIMARY KEY (ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_word_idx_ve_seq_tr
BEFORE INSERT ON answer_word_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_word_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
		
        DBMS_OUTPUT.PUT_LINE('swap mi data successful');		   
        UPDATE macro_index_status SET swap_lock = 0;
        UPDATE macro_index_status SET swap_ready = 0;        
      END;
    ELSE
      BEGIN  
        IF swap_lock_flag = 1 THEN
          DBMS_OUTPUT.PUT_LINE('Can not swap mi data as swap lock is already held');		   
        ELSE
          DBMS_OUTPUT.PUT_LINE('Can not swap mi data as mi data is not swap ready');		   
        END IF;
      END;
    END IF;
  END swapMIData;
/