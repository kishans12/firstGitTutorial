SET DEFINE OFF;
SET SCAN OFF;
-- Modified for VP-3056 STARTS
PROMPT Creating User enginedb ...
CREATE USER enginedb IDENTIFIED BY enginedb DEFAULT TABLESPACE USERS TEMPORARY TABLESPACE TEMP;
GRANT CREATE SESSION, CREATE SEQUENCE, CREATE TRIGGER, CREATE TABLE, RESOURCE, CREATE VIEW, CREATE MATERIALIZED VIEW, CREATE SYNONYM TO enginedb;

connect enginedb/enginedb;
-- Modified for VP-3056 ENDS

-- DROP TABLE dynamic_answer_dtl CASCADE CONSTRAINTS;
PROMPT Creating Table dynamic_answer_dtl ...
CREATE TABLE dynamic_answer_dtl (
  ANSWERID NUMBER(10,0) NOT NULL,
  ANSWER_TEXT CLOB,
  SUPPRESS_FLG NUMBER(3,0),
  VERSION VARCHAR2(255 CHAR) NOT NULL
);

PROMPT Creating Primary Key Constraint PRIMARY_12 on table dynamic_answer_dtl ... 
ALTER TABLE dynamic_answer_dtl
ADD CONSTRAINT PRIMARY_12 PRIMARY KEY
(
  ANSWERID,
  VERSION
)
ENABLE
;

-- DROP TABLE engine_startup_info CASCADE CONSTRAINTS;
PROMPT Creating Table engine_startup_info ...
CREATE TABLE engine_startup_info (
  NSCONTEXT VARCHAR2(255 CHAR),
  POANAME VARCHAR2(255 CHAR),
  STARTDATE DATE,
  TIME TIMESTAMP
);

-- Dumping structure for table alternate_hash
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE alternate_hash';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE alternate_hash (
  ALTERNATE_ID number(10) DEFAULT '0' NOT NULL,
  ALTERNATE_HASH varchar2(255) DEFAULT NULL,
  PRIMARY KEY (ALTERNATE_ID)
) ;

-- Dumping structure for duplicate table alternate_hash_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE alternate_hash_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE alternate_hash_ve (
  ALTERNATE_ID number(10) DEFAULT '0' NOT NULL,
  ALTERNATE_HASH varchar2(255) DEFAULT NULL,
  PRIMARY KEY (ALTERNATE_ID)
) ;

-- Dumping structure for table alternate_macro_index
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE alternate_macro_index';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE alternate_macro_index (
  ID number(10) NOT NULL,
  ALTERNATE_ID number(10) DEFAULT '0' NOT NULL,
  MACRO_ID number(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;

-- Dumping structure for duplicate table alternate_macro_index_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE alternate_macro_index_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE alternate_macro_index_ve (
  ID number(10) NOT NULL,
  ALTERNATE_ID number(10) DEFAULT '0' NOT NULL,
  MACRO_ID number(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE alternate_macro_index_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE alternate_macro_idx_ve_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER alternate_macro_index_seq_tr
 BEFORE INSERT ON alternate_macro_index FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
 SELECT alternate_macro_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

CREATE OR REPLACE TRIGGER alternate_macro_idx_ve_seq_tr
 BEFORE INSERT ON alternate_macro_index_ve FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
 SELECT alternate_macro_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

-- Dumping structure for table alternate_word_index
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE alternate_word_index';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE alternate_word_index (
  ID number(10) NOT NULL,
  ALTERNATE_ID number(10) DEFAULT '0' NOT NULL,
  WORD_ID number(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;


-- Dumping structure for duplicate table alternate_word_index_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE alternate_word_index_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE alternate_word_index_ve (
  ID number(10) NOT NULL,
  ALTERNATE_ID number(10) DEFAULT '0' NOT NULL,
  WORD_ID number(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE alternate_word_index_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE alternate_word_idx_ve_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER alternate_word_index_seq_tr
 BEFORE INSERT ON alternate_word_index FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
 SELECT alternate_word_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

CREATE OR REPLACE TRIGGER alternate_word_idx_ve_seq_tr
 BEFORE INSERT ON alternate_word_index_ve FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
 SELECT alternate_word_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

-- Dumping structure for table answer_hash
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE answer_hash';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE answer_hash (
  ANSWER_ID number(10) DEFAULT '0' NOT NULL,
  ANSWER_HASH varchar2(255) DEFAULT NULL,
  PRIMARY KEY (ANSWER_ID)
) ;

-- Dumping structure for duplicate table answer_hash_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE answer_hash_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE answer_hash_ve (
  ANSWER_ID number(10) DEFAULT '0' NOT NULL,
  ANSWER_HASH varchar2(255) DEFAULT NULL,
  PRIMARY KEY (ANSWER_ID)
) ;

-- Dumping structure for table answer_macro_index
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE answer_macro_index';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE answer_macro_index (
  ID number(10) NOT NULL,
  ANSWER_ID number(10) DEFAULT '0' NOT NULL,
  MACRO_ID number(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;

-- Dumping structure for duplicate table answer_macro_index_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE answer_macro_index_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE answer_macro_index_ve (
  ID number(10) NOT NULL,
  ANSWER_ID number(10) DEFAULT '0' NOT NULL,
  MACRO_ID number(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE answer_macro_index_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE answer_macro_idx_ve_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER answer_macro_index_seq_tr
 BEFORE INSERT ON answer_macro_index FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
 SELECT answer_macro_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

CREATE OR REPLACE TRIGGER answer_macro_idx_ve_seq_tr
 BEFORE INSERT ON answer_macro_index_ve FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
 SELECT answer_macro_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

-- Dumping structure for table answer_word_index
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE answer_word_index';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE answer_word_index (
  ID number(10) NOT NULL,
  ANSWER_ID number(10) DEFAULT '0' NOT NULL,
  WORD_ID number(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;


-- Dumping structure for duplicate table answer_word_index_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE answer_word_index_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE answer_word_index_ve (
  ID number(10) NOT NULL,
  ANSWER_ID number(10) DEFAULT '0' NOT NULL,
  WORD_ID number(10) DEFAULT NULL,
  PRIMARY KEY (ID)
) ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE answer_word_index_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE answer_word_idx_ve_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER answer_word_index_seq_tr
 BEFORE INSERT ON answer_word_index FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
 SELECT answer_word_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

CREATE OR REPLACE TRIGGER answer_word_idx_ve_seq_tr
 BEFORE INSERT ON answer_word_index_ve FOR EACH ROW
 WHEN (NEW.ID IS NULL)
BEGIN
 SELECT answer_word_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

-- Dumping structure for table macro_data
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE macro_data';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE macro_data (
  MACRO_ID number(10) DEFAULT '0' NOT NULL,
  MACRO_NAME varchar2(255) DEFAULT NULL,
  PRIMARY KEY (MACRO_ID)
) ;

-- Dumping structure for table macro_data_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE macro_data_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE macro_data_ve (
  MACRO_ID number(10) DEFAULT '0' NOT NULL,
  MACRO_NAME varchar2(255) DEFAULT NULL,
  PRIMARY KEY (MACRO_ID)
) ;

-- Dumping structure for table macro_hash
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE macro_hash';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE macro_hash (
  MACRO_ID number(10) DEFAULT '0' NOT NULL,
  MACRO_HASH varchar2(255) DEFAULT NULL,
  PRIMARY KEY (MACRO_ID)
) ;

-- Dumping structure for duplicate table macro_hash_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE macro_hash_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE macro_hash_ve (
  MACRO_ID number(10) DEFAULT '0' NOT NULL,
  MACRO_HASH varchar2(255) DEFAULT NULL,
  PRIMARY KEY (MACRO_ID)
) ;

-- Dumping structure for table macro_index_status
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE macro_index_status';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE macro_index_status (
  id number(10) NOT NULL,
  vengine_memory_write number(3) DEFAULT '0',
  vengine_write number(3) DEFAULT '0',
  vportal_read number(3) DEFAULT '0',
  swap_ready number(3) DEFAULT '0',
  swap_lock number(3) DEFAULT '0',
  publish_request number(3) DEFAULT '0',
  VENGINE_LAST_WRITE_TS timestamp(0) DEFAULT NULL NULL,
  VPORTAL_LAST_READ_TS timestamp(0) DEFAULT NULL NULL,
  VPORTAL_READ_SETBYVENGINE number(3) DEFAULT NULL,
  PRIMARY KEY (id)
) ;

-- Generate ID using sequence and trigger
CREATE SEQUENCE macro_index_status_seq START WITH 1 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER macro_index_status_seq_tr
 BEFORE INSERT ON macro_index_status FOR EACH ROW
 WHEN (NEW.id IS NULL)
BEGIN
 SELECT macro_index_status_seq.NEXTVAL INTO :NEW.id FROM DUAL;
END;
/

-- Dumping structure for table word_data
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE word_data';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE word_data (
  WORD_ID number(10) DEFAULT '0' NOT NULL,
  WORD_NAME varchar2(255) DEFAULT NULL,
  PRIMARY KEY (WORD_ID)
) ;


-- Dumping structure for duplicate table word_data_ve
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE word_data_ve';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
CREATE TABLE word_data_ve (
  WORD_ID number(10) DEFAULT '0' NOT NULL,
  WORD_NAME varchar2(255) DEFAULT NULL,
  PRIMARY KEY (WORD_ID)
) ;


-- AUTOCOMPLETE ---------------------------------------
--------------------------------------------------------
--  DDL for Table AC_CONDITION_ALT_WORD_INDEX
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_CONDITION_ALT_WORD_INDEX';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_CONDITION_ALT_WORD_INDEX 
   (	 ID number(10) NOT NULL, 
	ALTERNATE_ID NUMBER(10,0) DEFAULT '0' NOT NULL, 
	WORD_ID NUMBER(10,0) DEFAULT NULL,
	PRIMARY KEY (ID)
   );
 / 
 CREATE SEQUENCE  AC_COND_ALT_WORD_INDEX_SEQ  START WITH 1 INCREMENT BY 1;
 
create or replace 
trigger AC_COND_ALT_WORD_INDEX_SEQ_TR
 BEFORE INSERT ON AC_CONDITION_ALT_WORD_INDEX FOR EACH ROW
 BEGIN
 SELECT AC_COND_ALT_WORD_INDEX_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/

--------------------------------------------------------
--  DDL for Table AC_RECOGNITION_ALT_WORD_INDEX
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_RECOGNITION_ALT_WORD_INDEX';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_RECOGNITION_ALT_WORD_INDEX 
   (	 ID number(10) NOT NULL, 
	ALTERNATE_ID NUMBER(10,0) DEFAULT '0' NOT NULL, 
	WORD_ID NUMBER(10,0) DEFAULT NULL,
	PRIMARY KEY (ID)
   );
   
 CREATE SEQUENCE  AC_RECOG_ALT_WORD_INDEX_SEQ  START WITH 1 INCREMENT BY 1;
 
create or replace 
trigger AC_RECOG_ALT_WORD_INDEX_SEQ_TR
 BEFORE INSERT ON AC_RECOGNITION_ALT_WORD_INDEX FOR EACH ROW
 BEGIN
 SELECT AC_RECOG_ALT_WORD_INDEX_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/


--------------------------------------------------------
--  DDL for Table AC_ALTERNATE_HASH
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_ALTERNATE_HASH';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_ALTERNATE_HASH                                 
   (	ALTERNATE_ID NUMBER(10,0) DEFAULT '0' NOT NULL, 
	ALTERNATE_HASH VARCHAR2(255) DEFAULT NULL,
	PRIMARY KEY (ALTERNATE_ID)
   );

--------------------------------------------------------
--  DDL for Table AC_ANSWER_QUE_HASH
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_ANSWER_QUE_HASH';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_ANSWER_QUE_HASH
   (	ANSWER_ID NUMBER(10,0)DEFAULT '0' NOT NULL,
	ANSWER_QUESTION_HASH VARCHAR2(255 ) DEFAULT NULL,
	PRIMARY KEY (ANSWER_ID)
   );
--------------------------------------------------------
--  DDL for Table AC_ANSWER_QUE_WORD_INDEX
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_ANSWER_QUE_WORD_INDEX';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_ANSWER_QUE_WORD_INDEX
   ( ID number(10) NOT NULL, 
	ANSWER_ID NUMBER(10,0) DEFAULT '0' NOT NULL, 
	WORD_ID NUMBER(10,0) DEFAULT NULL,
	PRIMARY KEY (ID)
   );
   
 CREATE SEQUENCE AC_ANS_QUE_WORD_INDEX_SEQ  START WITH 1 INCREMENT BY 1;
 
create or replace 
trigger AC_ANS_QUE_WORD_INDEX_SEQ_TR
 BEFORE INSERT ON AC_ANSWER_QUE_WORD_INDEX FOR EACH ROW
 BEGIN
 SELECT AC_ANS_QUE_WORD_INDEX_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/


--------------------------------------------------------
--  DDL for Table AC_RECOGNITION_QUE_HASH
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_RECOGNITION_QUE_HASH';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_RECOGNITION_QUE_HASH
	 (	RECOGNITION_ID NUMBER(10,0) DEFAULT '0' NOT NULL,
		   RECOGNITION_HASH VARCHAR2(255 ) DEFAULT NULL,
		PRIMARY KEY (RECOGNITION_ID)
	 ) ;
--------------------------------------------------------
--  DDL for Table AC_RECOGNITION_QUE_WORD_INDEX
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_RECOGNITION_QUE_WORD_INDEX';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_RECOGNITION_QUE_WORD_INDEX
   ( ID number(10) NOT NULL, 
	RECOGNITION_ID NUMBER(10,0) DEFAULT '0' NOT NULL, 
	WORD_ID NUMBER(10,0) DEFAULT NULL,
	PRIMARY KEY (ID)
   );
   
 CREATE SEQUENCE AC_RECOG_QUE_WORD_INDEX_SEQ  START WITH 1 INCREMENT BY 1;
 
create or replace 
trigger AC_RECOG_QUE_WORD_INDEX_SEQ_TR
 BEFORE INSERT ON AC_RECOGNITION_QUE_WORD_INDEX FOR EACH ROW
 BEGIN
 SELECT AC_RECOG_QUE_WORD_INDEX_SEQ.NEXTVAL INTO :NEW.ID FROM DUAL;
END;
/
--------------------------------------------------------
--  DDL for Table AC_INDEX_STATUS
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_INDEX_STATUS';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_INDEX_STATUS
   (
   id number(10) NOT NULL,
  vengine_write number(3) DEFAULT '0',
  vportal_read number(3) DEFAULT '0',
  VENGINE_LAST_WRITE_TS timestamp(0) DEFAULT NULL NULL,
  VPORTAL_LAST_READ_TS timestamp(0) DEFAULT NULL NULL,
  VPORTAL_READ_SETBYVENGINE number(3) DEFAULT NULL,
  PRIMARY KEY (id)
  ) ;
  
  
CREATE SEQUENCE AC_INDEX_STATUS_SEQ  START WITH 1 INCREMENT BY 1; 
create or replace 
trigger AC_INDEX_STATUS_SEQ_TR
 BEFORE INSERT ON AC_INDEX_STATUS FOR EACH ROW
 BEGIN
 SELECT AC_INDEX_STATUS_SEQ.NEXTVAL INTO :NEW.id FROM DUAL;
END; 
/
--------------------------------------------------------
--  DDL for Table AC_WORD_DATA
--------------------------------------------------------
BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE AC_WORD_DATA';
EXCEPTION
   WHEN OTHERS THEN NULL;
END;
/
  CREATE TABLE AC_WORD_DATA
   (	   WORD_ID NUMBER(10,0) DEFAULT '0' NOT NULL,
		   WORD_NAME VARCHAR2(255 ) DEFAULT NULL,
		   PRIMARY KEY (WORD_ID)
   );

-- AUTOCOMPLETE ---------------------------------------

-- VP-3624
PROMPT Creating Table engine_version ...
CREATE TABLE engine_version 
(
  VERSION VARCHAR2(10) NOT NULL
);
--------------------------------------------------------
--  File created - Tuesday-May-12-2015   
--------------------------------------------------------
----- Function INET_ATON equivalent to MSSQL --------------------------------- 

CREATE OR REPLACE 
FUNCTION "INET_ATON" ( p_str in varchar2 ) return number
AS
	p_str1 varchar2(50):= p_str;
	l_dot1 number := instr( p_str1, '.',1,1 );
	l_dot2 number := instr( p_str1, '.',1,2 );
	l_dot3 number := instr( p_str1, '.',1,3 );
	ip1 varchar2(10);
	ip2 varchar2(10);
	ip  varchar2(80);
								
BEGIN
	IF l_dot1 = 0 THEN
		return to_number(p_str1);
	END IF;
	IF l_dot2 = 0 THEN
		ip1  := substr(p_str1,1,l_dot1);
		ip2  := substr(p_str1,l_dot1);
		p_str1  := CONCAT(CONCAT(CONCAT(CONCAT(ip1,'0'),'.'),'0'),ip2);
		l_dot1  := instr(p_str1, '.',1,1 );
		l_dot2  := instr(p_str1, '.',1,2 );
		l_dot3  := instr( p_str1, '.',1,3 );
		DBMS_OUTPUT.PUT_LINE(p_str1);
	END IF;
	return
		to_number(substr(p_str1,1,l_dot1-1))*power(256,3)+
		to_number(substr(p_str1,l_dot1+1, l_dot2-l_dot1-1))*power(256,2)+
		to_number(substr(p_str1,l_dot2+1,l_dot3-l_dot2-1))*256+
		to_number(substr(p_str1,l_dot3+1));
END;
/

create or replace 
PROCEDURE swapMIData 
IS
swap_ready_flag NUMBER(3,0);
swap_lock_flag NUMBER(3,0);
BEGIN
  SELECT mistatus.swap_ready INTO swap_ready_flag FROM macro_index_status mistatus;
  SELECT mistatus.swap_lock INTO swap_lock_flag FROM macro_index_status mistatus;
      
    IF swap_lock_flag = 0 and swap_ready_flag = 1 then
      BEGIN
	  
        UPDATE macro_index_status SET swap_lock = 1;			
			
        EXECUTE IMMEDIATE('DROP TABLE alternate_hash');
        EXECUTE IMMEDIATE('DROP TABLE answer_hash');
        EXECUTE IMMEDIATE('DROP TABLE macro_hash');
        EXECUTE IMMEDIATE('DROP TABLE macro_data');
        EXECUTE IMMEDIATE('DROP TABLE word_data');
        EXECUTE IMMEDIATE('DROP TABLE alternate_macro_index');
        EXECUTE IMMEDIATE('DROP TABLE alternate_word_index');
        EXECUTE IMMEDIATE('DROP TABLE answer_macro_index');
        EXECUTE IMMEDIATE('DROP TABLE answer_word_index');		
        
        EXECUTE IMMEDIATE('ALTER TABLE alternate_hash_ve RENAME TO alternate_hash');
        EXECUTE IMMEDIATE('ALTER TABLE answer_hash_ve RENAME TO answer_hash');
        EXECUTE IMMEDIATE('ALTER TABLE macro_hash_ve RENAME TO macro_hash');
        EXECUTE IMMEDIATE('ALTER TABLE macro_data_ve RENAME TO macro_data');
        EXECUTE IMMEDIATE('ALTER TABLE word_data_ve RENAME TO word_data');
        EXECUTE IMMEDIATE('ALTER TABLE alternate_macro_index_ve RENAME TO alternate_macro_index');
        EXECUTE IMMEDIATE('ALTER TABLE alternate_word_index_ve RENAME TO alternate_word_index');
        EXECUTE IMMEDIATE('ALTER TABLE answer_macro_index_ve RENAME TO answer_macro_index');
        EXECUTE IMMEDIATE('ALTER TABLE answer_word_index_ve RENAME TO answer_word_index');        
        
        EXECUTE IMMEDIATE('DROP TRIGGER alternate_macro_idx_ve_seq_tr');
        EXECUTE IMMEDIATE('DROP TRIGGER alternate_word_idx_ve_seq_tr');
        EXECUTE IMMEDIATE('DROP TRIGGER answer_macro_idx_ve_seq_tr');
        EXECUTE IMMEDIATE('DROP TRIGGER answer_word_idx_ve_seq_tr');
		
		EXECUTE IMMEDIATE('DROP SEQUENCE alternate_macro_index_seq');
		EXECUTE IMMEDIATE('DROP SEQUENCE alternate_word_index_seq');
		EXECUTE IMMEDIATE('DROP SEQUENCE answer_macro_index_seq');
		EXECUTE IMMEDIATE('DROP SEQUENCE answer_word_index_seq');

		EXECUTE IMMEDIATE('RENAME alternate_macro_idx_ve_seq TO alternate_macro_index_seq');
		EXECUTE IMMEDIATE('RENAME alternate_word_idx_ve_seq TO alternate_word_index_seq');
		EXECUTE IMMEDIATE('RENAME answer_macro_idx_ve_seq TO answer_macro_index_seq');
		EXECUTE IMMEDIATE('RENAME answer_word_idx_ve_seq TO answer_word_index_seq');
		
		EXECUTE IMMEDIATE('CREATE SEQUENCE alternate_macro_idx_ve_seq START WITH 1 INCREMENT BY 1');
		EXECUTE IMMEDIATE('CREATE SEQUENCE alternate_word_idx_ve_seq START WITH 1 INCREMENT BY 1');
		EXECUTE IMMEDIATE('CREATE SEQUENCE answer_macro_idx_ve_seq START WITH 1 INCREMENT BY 1');
		EXECUTE IMMEDIATE('CREATE SEQUENCE answer_word_idx_ve_seq START WITH 1 INCREMENT BY 1');
     
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_macro_index_seq_tr
BEFORE INSERT ON alternate_macro_index FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_macro_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
                  
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_word_index_seq_tr
BEFORE INSERT ON alternate_word_index FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_word_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
    
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_macro_index_seq_tr
BEFORE INSERT ON answer_macro_index FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_macro_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
        
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_word_index_seq_tr
BEFORE INSERT ON answer_word_index FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_word_index_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
    
        EXECUTE IMMEDIATE('CREATE TABLE alternate_hash_ve (
                    ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
                    ALTERNATE_HASH varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (ALTERNATE_ID)
                  )');	
                  
        EXECUTE IMMEDIATE('CREATE TABLE answer_hash_ve (
                    ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
                    ANSWER_HASH varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (ANSWER_ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE TABLE macro_hash_ve (
                    MACRO_ID number(10) DEFAULT ''0'' NOT NULL,
                    MACRO_HASH varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (MACRO_ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE TABLE macro_data_ve (
                    MACRO_ID number(10) DEFAULT ''0'' NOT NULL,
                    MACRO_NAME varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (MACRO_ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE TABLE word_data_ve (
                    WORD_ID number(10) DEFAULT ''0'' NOT NULL,
                    WORD_NAME varchar2(255) DEFAULT NULL,
                    PRIMARY KEY (WORD_ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE TABLE alternate_macro_index_ve (
                    ID number(10) NOT NULL,
                    ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
                    MACRO_ID number(10) DEFAULT NULL,
                    PRIMARY KEY (ID)
                  )');	
        
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_macro_idx_ve_seq_tr
BEFORE INSERT ON alternate_macro_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_macro_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
                  
        EXECUTE IMMEDIATE('CREATE TABLE alternate_word_index_ve (
                    ID number(10) NOT NULL,
                    ALTERNATE_ID number(10) DEFAULT ''0'' NOT NULL,
                    WORD_ID number(10) DEFAULT NULL,
                    PRIMARY KEY (ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER alternate_word_idx_ve_seq_tr
BEFORE INSERT ON alternate_word_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT alternate_word_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
    
        EXECUTE IMMEDIATE('CREATE TABLE answer_macro_index_ve (
                    ID number(10) NOT NULL,
                    ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
                    MACRO_ID number(10) DEFAULT NULL,
                    PRIMARY KEY (ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_macro_idx_ve_seq_tr
BEFORE INSERT ON answer_macro_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_macro_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
    
        EXECUTE IMMEDIATE('CREATE TABLE answer_word_index_ve (
                    ID number(10) NOT NULL,
                    ANSWER_ID number(10) DEFAULT ''0'' NOT NULL,
                    WORD_ID number(10) DEFAULT NULL,
                    PRIMARY KEY (ID)
                  )');
                  
        EXECUTE IMMEDIATE('CREATE OR REPLACE TRIGGER answer_word_idx_ve_seq_tr
BEFORE INSERT ON answer_word_index_ve FOR EACH ROW
WHEN (NEW.ID IS NULL)
BEGIN
  SELECT answer_word_idx_ve_seq.NEXTVAL INTO :NEW.ID FROM DUAL;
END;');
		
        DBMS_OUTPUT.PUT_LINE('MI data swap successful');		   
        UPDATE macro_index_status SET swap_lock = 0;
        UPDATE macro_index_status SET swap_ready = 0;        
      END;
    ELSE
      BEGIN  
        IF swap_lock_flag = 1 THEN
          DBMS_OUTPUT.PUT_LINE('Can not swap mi data as swap lock is already held');		   
        ELSE
          DBMS_OUTPUT.PUT_LINE('Can not swap mi data as mi data is not swap ready');		   
        END IF;
      END;
    END IF;
  END swapMIData;
/

/
DISCONNECT;
